import pandas as pd
import numpy as np
import re

# Load your datasets
category_data = pd.read_csv(r"C:\Users\pngoc\Downloads\Smart-Talent-Resume-Ranker-kapil-development\Smart-Talent-Resume-Ranker-kapil-development\Datasets\category.csv")  # Adjust the filename
jobs_classify_data = pd.read_csv(r"C:\Users\pngoc\Downloads\Smart-Talent-Resume-Ranker-kapil-development\Smart-Talent-Resume-Ranker-kapil-development\Datasets\jobs_classify.csv")  # Adjust the filename
resume_skills_data = pd.read_csv(r"C:\Users\pngoc\Downloads\Smart-Talent-Resume-Ranker-kapil-development\Smart-Talent-Resume-Ranker-kapil-development\Datasets\resume_skills_data.csv")  # Adjust the filename
jobs_skills_data = pd.read_csv(r"C:\Users\pngoc\Downloads\Smart-Talent-Resume-Ranker-kapil-development\Smart-Talent-Resume-Ranker-kapil-development\Datasets\jobs_skills_data.csv")  # Adjust the filename
new_skills_data = pd.read_csv(r"C:\Users\pngoc\Downloads\Smart-Talent-Resume-Ranker-kapil-development\Smart-Talent-Resume-Ranker-kapil-development\Datasets\new_skills_data.csv")  # Adjust the filename
skill_set_data = pd.read_csv(r"C:\Users\pngoc\Downloads\Smart-Talent-Resume-Ranker-kapil-development\Smart-Talent-Resume-Ranker-kapil-development\Datasets\skill_set_data.csv")  # Adjust the filename

# Function to clean text data
def clean_text(text):
    # Lowercase
    text = text.lower()
    # Remove special characters and extra whitespace
    text = re.sub(r'[^a-z0-9\s]', '', text)
    text = re.sub(r'\s+', ' ', text).strip()
    return text

# Clean Category Data
category_data['category'] = category_data['category'].apply(clean_text)
category_data.drop_duplicates(subset=['category'], inplace=True)

# Clean Jobs Classify Data
jobs_classify_data['text'] = jobs_classify_data['text'].apply(clean_text)
jobs_classify_data['skills'] = jobs_classify_data['skills'].apply(lambda x: x.strip("[]").replace("'", "").lower().split(','))
jobs_classify_data.drop(columns=[col for col in jobs_classify_data.columns if 'Unnamed' in col], inplace=True)
jobs_classify_data.drop_duplicates(inplace=True)

# Clean Resume Skills Data
resume_skills_data['Resume'] = resume_skills_data['Resume'].apply(clean_text)
resume_skills_data['skills'] = resume_skills_data['skills'].apply(lambda x: x.strip("[]").replace("'", "").lower().split(','))
resume_skills_data.drop_duplicates(inplace=True)

# Clean Jobs Skills Data
jobs_skills_data['skills'] = jobs_skills_data['skills'].apply(lambda x: x.strip("[]").replace("'", "").lower().split(','))
jobs_skills_data.drop_duplicates(inplace=True)

# Clean New Skills Data
new_skills_data['skills'] = new_skills_data['skills'].apply(clean_text)
new_skills_data.drop_duplicates(inplace=True)

# Clean Skill Set Data
skill_set_data['skills'] = skill_set_data['skills'].apply(clean_text)
skill_set_data.drop_duplicates(inplace=True)

# Save cleaned datasets to new CSV files
category_data.to_csv('cleaned_category_data.csv', index=False)
jobs_classify_data.to_csv('cleaned_jobs_classify_data.csv', index=False)
resume_skills_data.to_csv('cleaned_resume_skills_data.csv', index=False)
jobs_skills_data.to_csv('cleaned_jobs_skills_data.csv', index=False)
new_skills_data.to_csv('cleaned_new_skills_data.csv', index=False)
skill_set_data.to_csv('cleaned_skill_set_data.csv', index=False)

print("Data cleaning completed and cleaned datasets saved.")
